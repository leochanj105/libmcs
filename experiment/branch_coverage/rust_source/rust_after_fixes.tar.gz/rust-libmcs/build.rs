use std::env;
use std::path::{Path, PathBuf};

fn add_sources(build: &mut cc::Build, dir: &Path) {
    let mut entries: Vec<PathBuf> = std::fs::read_dir(dir)
        .unwrap()
        .filter_map(|entry| entry.ok().map(|e| e.path()))
        .filter(|path| path.extension().and_then(|ext| ext.to_str()) == Some("c"))
        .collect();
    entries.sort();

    for path in entries {
        if path.file_name().and_then(|name| name.to_str()) == Some("fenv.c") {
            continue;
        }
        build.file(path);
    }
}

fn main() {
    let manifest_dir = PathBuf::from(env::var_os("CARGO_MANIFEST_DIR").unwrap());
    let source_root = manifest_dir.parent().unwrap();
    let include_dir = source_root.join("build-x86_64-linux-gnu/include");
    let libm_root = source_root.join("libm");

    println!("cargo:rerun-if-changed={}", include_dir.display());
    println!("cargo:rerun-if-changed={}", libm_root.display());

    let mut build = cc::Build::new();
    build
        .include(&include_dir)
        .flag_if_supported("-std=c11")
        .warnings(false);

    for subdir in ["common", "mathd", "mathf", "complexd", "complexf"] {
        add_sources(&mut build, &libm_root.join(subdir));
    }
    for subdir in [
        "mathd/internal",
        "mathf/internal",
        "complexd/internal",
        "complexf/internal",
    ] {
        add_sources(&mut build, &libm_root.join(subdir));
    }

    build.compile("mcs");
}

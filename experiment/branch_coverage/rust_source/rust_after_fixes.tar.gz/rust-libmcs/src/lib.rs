use core::ffi::{c_char, c_int, c_long, c_longlong};

#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct Complex32 {
    pub re: f32,
    pub im: f32,
}

#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct Complex64 {
    pub re: f64,
    pub im: f64,
}

macro_rules! wrap_f64_unary {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f64) -> f64;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f64) -> f64 {
            $name(x)
        }
    };
}

macro_rules! wrap_f64_binary {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f64, y: f64) -> f64;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f64, y: f64) -> f64 {
            $name(x, y)
        }
    };
}

macro_rules! wrap_f64_ternary {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f64, y: f64, z: f64) -> f64;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f64, y: f64, z: f64) -> f64 {
            $name(x, y, z)
        }
    };
}

macro_rules! wrap_f32_unary {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f32) -> f32;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f32) -> f32 {
            $name(x)
        }
    };
}

macro_rules! wrap_f32_binary {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f32, y: f32) -> f32;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f32, y: f32) -> f32 {
            $name(x, y)
        }
    };
}

macro_rules! wrap_f32_ternary {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f32, y: f32, z: f32) -> f32;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f32, y: f32, z: f32) -> f32 {
            $name(x, y, z)
        }
    };
}

macro_rules! wrap_f64_ptr_i32 {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f64, out: *mut c_int) -> f64;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f64, out: *mut c_int) -> f64 {
            $name(x, out)
        }
    };
}

macro_rules! wrap_f32_ptr_i32 {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f32, out: *mut c_int) -> f32;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f32, out: *mut c_int) -> f32 {
            $name(x, out)
        }
    };
}

macro_rules! wrap_f64_i32_ret {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f64) -> c_int;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f64) -> c_int {
            $name(x)
        }
    };
}

macro_rules! wrap_f32_i32_ret {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f32) -> c_int;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f32) -> c_int {
            $name(x)
        }
    };
}

macro_rules! wrap_f64_i64_ret {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f64) -> c_long;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f64) -> c_long {
            $name(x)
        }
    };
}

macro_rules! wrap_f32_i64_ret {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f32) -> c_long;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f32) -> c_long {
            $name(x)
        }
    };
}

macro_rules! wrap_f64_i128_ret {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f64) -> c_longlong;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f64) -> c_longlong {
            $name(x)
        }
    };
}

macro_rules! wrap_f32_i128_ret {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f32) -> c_longlong;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f32) -> c_longlong {
            $name(x)
        }
    };
}

macro_rules! wrap_f64_with_i32 {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f64, y: c_int) -> f64;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f64, y: c_int) -> f64 {
            $name(x, y)
        }
    };
}

macro_rules! wrap_f32_with_i32 {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f32, y: c_int) -> f32;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f32, y: c_int) -> f32 {
            $name(x, y)
        }
    };
}

macro_rules! wrap_f64_with_long {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f64, y: c_long) -> f64;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f64, y: c_long) -> f64 {
            $name(x, y)
        }
    };
}

macro_rules! wrap_f32_with_long {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f32, y: c_long) -> f32;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f32, y: c_long) -> f32 {
            $name(x, y)
        }
    };
}

macro_rules! wrap_f64_str_arg {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(tagp: *const c_char) -> f64;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(tagp: *const c_char) -> f64 {
            $name(tagp)
        }
    };
}

macro_rules! wrap_f32_str_arg {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(tagp: *const c_char) -> f32;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(tagp: *const c_char) -> f32 {
            $name(tagp)
        }
    };
}

macro_rules! wrap_f64_ptr_f64 {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f64, out: *mut f64) -> f64;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f64, out: *mut f64) -> f64 {
            $name(x, out)
        }
    };
}

macro_rules! wrap_f32_ptr_f32 {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f32, out: *mut f32) -> f32;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f32, out: *mut f32) -> f32 {
            $name(x, out)
        }
    };
}

macro_rules! wrap_f64_f64_ptr_i32 {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f64, y: f64, quo: *mut c_int) -> f64;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f64, y: f64, quo: *mut c_int) -> f64 {
            $name(x, y, quo)
        }
    };
}

macro_rules! wrap_f32_f32_ptr_i32 {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f32, y: f32, quo: *mut c_int) -> f32;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f32, y: f32, quo: *mut c_int) -> f32 {
            $name(x, y, quo)
        }
    };
}

macro_rules! wrap_f64_complex_unary {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(z: Complex64) -> Complex64;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(z: Complex64) -> Complex64 {
            $name(z)
        }
    };
}

macro_rules! wrap_f32_complex_unary {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(z: Complex32) -> Complex32;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(z: Complex32) -> Complex32 {
            $name(z)
        }
    };
}

macro_rules! wrap_f64_complex_scalar {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(z: Complex64) -> f64;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(z: Complex64) -> f64 {
            $name(z)
        }
    };
}

macro_rules! wrap_f32_complex_scalar {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(z: Complex32) -> f32;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(z: Complex32) -> f32 {
            $name(z)
        }
    };
}

macro_rules! wrap_f64_complex_binary {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: Complex64, y: Complex64) -> Complex64;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: Complex64, y: Complex64) -> Complex64 {
            $name(x, y)
        }
    };
}

macro_rules! wrap_f32_complex_binary {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: Complex32, y: Complex32) -> Complex32;
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: Complex32, y: Complex32) -> Complex32 {
            $name(x, y)
        }
    };
}

macro_rules! wrap_ccoshsinh_f64 {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f64, c: *mut f64, s: *mut f64);
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f64, c: *mut f64, s: *mut f64) {
            $name(x, c, s)
        }
    };
}

macro_rules! wrap_ccoshsinh_f32 {
    ($name:ident, $wrapper:ident) => {
        unsafe extern "C" {
            fn $name(x: f32, c: *mut f32, s: *mut f32);
        }

        #[no_mangle]
        pub unsafe extern "C" fn $wrapper(x: f32, c: *mut f32, s: *mut f32) {
            $name(x, c, s)
        }
    };
}

wrap_f64_unary!(acos, acos_rs);
wrap_f64_unary!(acosh, acosh_rs);
wrap_f64_unary!(asin, asin_rs);
wrap_f64_unary!(asinh, asinh_rs);
wrap_f64_binary!(atan2, atan2_rs);
wrap_f64_unary!(atan, atan_rs);
wrap_f64_unary!(atanh, atanh_rs);
wrap_f64_unary!(cbrt, cbrt_rs);
wrap_f64_unary!(ceil, ceil_rs);
wrap_f64_binary!(copysign, copysign_rs);
wrap_f64_unary!(cos, cos_rs);
wrap_f64_unary!(cosh, cosh_rs);
wrap_f64_unary!(erf, erf_rs);
wrap_f64_unary!(erfc, erfc_rs);
wrap_f64_unary!(exp, exp_rs);
wrap_f64_unary!(exp2, exp2_rs);
wrap_f64_unary!(expm1, expm1_rs);
wrap_f64_unary!(fabs, fabs_rs);
wrap_f64_binary!(fdim, fdim_rs);
wrap_f64_unary!(floor, floor_rs);
wrap_f64_ternary!(fma, fma_rs);
wrap_f64_binary!(fmax, fmax_rs);
wrap_f64_binary!(fmin, fmin_rs);
wrap_f64_binary!(fmod, fmod_rs);
wrap_f64_ptr_i32!(frexp, frexp_rs);
wrap_f64_binary!(hypot, hypot_rs);
wrap_f64_i32_ret!(ilogb, ilogb_rs);
wrap_f64_with_i32!(ldexp, ldexp_rs);
wrap_f64_unary!(lgamma, lgamma_rs);
wrap_f64_i128_ret!(llrint, llrint_rs);
wrap_f64_i128_ret!(llround, llround_rs);
wrap_f64_unary!(log, log_rs);
wrap_f64_unary!(log10, log10_rs);
wrap_f64_unary!(log1p, log1p_rs);
wrap_f64_unary!(log2, log2_rs);
wrap_f64_unary!(logb, logb_rs);
wrap_f64_i64_ret!(lrint, lrint_rs);
wrap_f64_i64_ret!(lround, lround_rs);
wrap_f64_ptr_f64!(modf, modf_rs);
wrap_f64_str_arg!(nan, nan_rs);
wrap_f64_unary!(nearbyint, nearbyint_rs);
wrap_f64_binary!(nextafter, nextafter_rs);
wrap_f64_binary!(pow, pow_rs);
wrap_f64_binary!(remainder, remainder_rs);
wrap_f64_f64_ptr_i32!(remquo, remquo_rs);
wrap_f64_unary!(rint, rint_rs);
wrap_f64_unary!(round, round_rs);
wrap_f64_with_long!(scalbln, scalbln_rs);
wrap_f64_with_i32!(scalbn, scalbn_rs);
wrap_f64_unary!(sin, sin_rs);
wrap_f64_unary!(sinh, sinh_rs);
wrap_f64_unary!(sqrt, sqrt_rs);
wrap_f64_unary!(tan, tan_rs);
wrap_f64_unary!(tanh, tanh_rs);
wrap_f64_unary!(tgamma, tgamma_rs);
wrap_f64_unary!(trunc, trunc_rs);
wrap_f64_unary!(y0, y0_rs);
wrap_f64_unary!(y1, y1_rs);

unsafe extern "C" {
    fn yn(n: c_int, x: f64) -> f64;
    fn j0(x: f64) -> f64;
    fn j1(x: f64) -> f64;
    fn jn(n: c_int, x: f64) -> f64;
}

#[no_mangle]
pub unsafe extern "C" fn yn_rs(n: c_int, x: f64) -> f64 {
    yn(n, x)
}

#[no_mangle]
pub unsafe extern "C" fn j0_rs(x: f64) -> f64 {
    j0(x)
}

#[no_mangle]
pub unsafe extern "C" fn j1_rs(x: f64) -> f64 {
    j1(x)
}

#[no_mangle]
pub unsafe extern "C" fn jn_rs(n: c_int, x: f64) -> f64 {
    jn(n, x)
}

wrap_f32_unary!(acosf, acosf_rs);
wrap_f32_unary!(acoshf, acoshf_rs);
wrap_f32_unary!(asinf, asinf_rs);
wrap_f32_unary!(asinhf, asinhf_rs);
wrap_f32_binary!(atan2f, atan2f_rs);
wrap_f32_unary!(atanf, atanf_rs);
wrap_f32_unary!(atanhf, atanhf_rs);
wrap_f32_unary!(cbrtf, cbrtf_rs);
wrap_f32_unary!(ceilf, ceilf_rs);
wrap_f32_binary!(copysignf, copysignf_rs);
wrap_f32_unary!(cosf, cosf_rs);
wrap_f32_unary!(coshf, coshf_rs);
wrap_f32_unary!(erfcf, erfcf_rs);
wrap_f32_unary!(erff, erff_rs);
wrap_f32_unary!(exp2f, exp2f_rs);
wrap_f32_unary!(expf, expf_rs);
wrap_f32_unary!(expm1f, expm1f_rs);
wrap_f32_unary!(fabsf, fabsf_rs);
wrap_f32_binary!(fdimf, fdimf_rs);
wrap_f32_unary!(floorf, floorf_rs);
wrap_f32_ternary!(fmaf, fmaf_rs);
wrap_f32_binary!(fmaxf, fmaxf_rs);
wrap_f32_binary!(fminf, fminf_rs);
wrap_f32_binary!(fmodf, fmodf_rs);
wrap_f32_ptr_i32!(frexpf, frexpf_rs);
wrap_f32_binary!(hypotf, hypotf_rs);
wrap_f32_i32_ret!(ilogbf, ilogbf_rs);
wrap_f32_with_i32!(ldexpf, ldexpf_rs);
wrap_f32_unary!(lgammaf, lgammaf_rs);
wrap_f32_i128_ret!(llrintf, llrintf_rs);
wrap_f32_i128_ret!(llroundf, llroundf_rs);
wrap_f32_unary!(log10f, log10f_rs);
wrap_f32_unary!(log1pf, log1pf_rs);
wrap_f32_unary!(log2f, log2f_rs);
wrap_f32_unary!(logbf, logbf_rs);
wrap_f32_unary!(logf, logf_rs);
wrap_f32_i64_ret!(lrintf, lrintf_rs);
wrap_f32_i64_ret!(lroundf, lroundf_rs);
wrap_f32_ptr_f32!(modff, modff_rs);
wrap_f32_str_arg!(nanf, nanf_rs);
wrap_f32_unary!(nearbyintf, nearbyintf_rs);
wrap_f32_binary!(nextafterf, nextafterf_rs);
wrap_f32_binary!(powf, powf_rs);
wrap_f32_binary!(remainderf, remainderf_rs);
wrap_f32_f32_ptr_i32!(remquof, remquof_rs);
wrap_f32_unary!(rintf, rintf_rs);
wrap_f32_unary!(roundf, roundf_rs);
wrap_f32_with_long!(scalblnf, scalblnf_rs);
wrap_f32_with_i32!(scalbnf, scalbnf_rs);
wrap_f32_unary!(sinf, sinf_rs);
wrap_f32_unary!(sinhf, sinhf_rs);
wrap_f32_unary!(sqrtf, sqrtf_rs);
wrap_f32_unary!(tanf, tanf_rs);
wrap_f32_unary!(tanhf, tanhf_rs);
wrap_f32_unary!(tgammaf, tgammaf_rs);
wrap_f32_unary!(truncf, truncf_rs);

wrap_f64_complex_scalar!(cabs, cabs_rs);
wrap_f64_complex_unary!(cacos, cacos_rs);
wrap_f64_complex_unary!(cacosh, cacosh_rs);
wrap_f64_complex_scalar!(carg, carg_rs);
wrap_f64_complex_unary!(casin, casin_rs);
wrap_f64_complex_unary!(casinh, casinh_rs);
wrap_f64_complex_unary!(catan, catan_rs);
wrap_f64_complex_unary!(catanh, catanh_rs);
wrap_f64_complex_unary!(ccos, ccos_rs);
wrap_f64_complex_unary!(ccosh, ccosh_rs);
wrap_f64_complex_unary!(cexp, cexp_rs);
wrap_f64_complex_scalar!(cimag, cimag_rs);
wrap_f64_complex_unary!(clog, clog_rs);
wrap_f64_complex_unary!(conj, conj_rs);
wrap_f64_complex_binary!(cpow, cpow_rs);
wrap_f64_complex_unary!(cproj, cproj_rs);
wrap_f64_complex_scalar!(creal, creal_rs);
wrap_f64_complex_unary!(csin, csin_rs);
wrap_f64_complex_unary!(csinh, csinh_rs);
wrap_f64_complex_unary!(csqrt, csqrt_rs);
wrap_f64_complex_unary!(ctan, ctan_rs);
wrap_f64_complex_unary!(ctanh, ctanh_rs);

wrap_f32_complex_scalar!(cabsf, cabsf_rs);
wrap_f32_complex_unary!(cacosf, cacosf_rs);
wrap_f32_complex_unary!(cacoshf, cacoshf_rs);
wrap_f32_complex_scalar!(cargf, cargf_rs);
wrap_f32_complex_unary!(casinf, casinf_rs);
wrap_f32_complex_unary!(casinhf, casinhf_rs);
wrap_f32_complex_unary!(catanf, catanf_rs);
wrap_f32_complex_unary!(catanhf, catanhf_rs);
wrap_f32_complex_unary!(ccosf, ccosf_rs);
wrap_f32_complex_unary!(ccoshf, ccoshf_rs);
wrap_f32_complex_unary!(cexpf, cexpf_rs);
wrap_f32_complex_scalar!(cimagf, cimagf_rs);
wrap_f32_complex_unary!(clogf, clogf_rs);
wrap_f32_complex_unary!(conjf, conjf_rs);
wrap_f32_complex_binary!(cpowf, cpowf_rs);
wrap_f32_complex_unary!(cprojf, cprojf_rs);
wrap_f32_complex_scalar!(crealf, crealf_rs);
wrap_f32_complex_unary!(csinf, csinf_rs);
wrap_f32_complex_unary!(csinhf, csinhf_rs);
wrap_f32_complex_unary!(csqrtf, csqrtf_rs);
wrap_f32_complex_unary!(ctanf, ctanf_rs);
wrap_f32_complex_unary!(ctanhf, ctanhf_rs);

wrap_f64_i32_ret!(__fpclassifyd, __fpclassifyd_rs);
wrap_f32_i32_ret!(__fpclassifyf, __fpclassifyf_rs);
wrap_f64_i32_ret!(__signbitd, __signbitd_rs);
wrap_f32_i32_ret!(__signbitf, __signbitf_rs);
wrap_f64_ptr_i32!(__lgamma, __lgamma_rs);
wrap_f32_ptr_i32!(__lgammaf, __lgammaf_rs);
wrap_f64_unary!(__redupi, __redupi_rs);
wrap_f32_unary!(__redupif, __redupif_rs);
wrap_ccoshsinh_f64!(__ccoshsinh, __ccoshsinh_rs);
wrap_ccoshsinh_f32!(__ccoshsinhf, __ccoshsinhf_rs);

unsafe extern "C" {
    fn __cos(x: f64, y: f64) -> f64;
    fn __sin(x: f64, y: f64, iy: c_int) -> f64;
    fn __rem_pio2(x: f64, y: *mut f64) -> i32;
    fn __cosf(x: f32, y: f32) -> f32;
    fn __sinf(x: f32, y: f32, iy: c_int) -> f32;
    fn __rem_pio2f(x: f32, y: *mut f32) -> i32;
}

#[no_mangle]
pub unsafe extern "C" fn __cos_rs(x: f64, y: f64) -> f64 {
    __cos(x, y)
}

#[no_mangle]
pub unsafe extern "C" fn __sin_rs(x: f64, y: f64, iy: c_int) -> f64 {
    __sin(x, y, iy)
}

#[no_mangle]
pub unsafe extern "C" fn __rem_pio2_rs(x: f64, y: *mut f64) -> i32 {
    __rem_pio2(x, y)
}

#[no_mangle]
pub unsafe extern "C" fn __cosf_rs(x: f32, y: f32) -> f32 {
    __cosf(x, y)
}

#[no_mangle]
pub unsafe extern "C" fn __sinf_rs(x: f32, y: f32, iy: c_int) -> f32 {
    __sinf(x, y, iy)
}

#[no_mangle]
pub unsafe extern "C" fn __rem_pio2f_rs(x: f32, y: *mut f32) -> i32 {
    __rem_pio2f(x, y)
}
